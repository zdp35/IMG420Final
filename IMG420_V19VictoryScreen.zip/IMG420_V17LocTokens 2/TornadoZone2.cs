using Godot;

public partial class TornadoZone2 : Area2D
{
	[Export] public float LaunchVelocity = -900f;
	[Export] public float HorizontalBoost = 0f;
	[Export] public float CooldownSeconds = 0.3f;

	private double _cooldownTimer = 0.0;

	public override void _Process(double delta)
	{
		if (_cooldownTimer > 0.0)
			_cooldownTimer -= delta;
	}

	public override void _Ready()
	{
		BodyEntered += OnBodyEntered;
	}

	private void OnBodyEntered(Node2D body)
	{
		if (_cooldownTimer > 0.0)
			return;

		if (body is Player player)
		{
			Vector2 v = player.Velocity;
			v.Y = LaunchVelocity;

			if (HorizontalBoost != 0f)
				v.X += HorizontalBoost;

			player.Velocity = v;
			_cooldownTimer = CooldownSeconds;
		}
	}
}
