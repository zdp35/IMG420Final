using Godot;

public partial class Player : CharacterBody2D
{
	[Export] public float MoveSpeed = 260f;
	[Export] public float JumpVelocity = -400f;
	[Export] public float Gravity = 900f;

	public bool IsInHurricane { get; set; } = false;
	public HurricaneZone ActiveHurricaneZone { get; set; } = null;

	public override void _PhysicsProcess(double delta)
	{
		Vector2 v = Velocity;

		// ----------------------------
		// Gravity
		// ----------------------------
		if (!IsOnFloor())
			v.Y += Gravity * (float)delta;

		// ----------------------------
		// Player Horizontal Input
		// ----------------------------
		float inputDir = 0f;

		if (Input.IsActionPressed("ui_left"))
			inputDir -= 1f;
		if (Input.IsActionPressed("ui_right"))
			inputDir += 1f;

		// ----------------------------
		// Movement model:
		//  - Normal: direct control v.X = input * speed
		//  - Hurricane: slidy accel/friction model
		// ----------------------------
		if (ActiveHurricaneZone != null)
		{
			var hz = ActiveHurricaneZone;

			float targetX = inputDir * MoveSpeed;
			float accel = hz.HurricaneAccel;
			float friction = hz.HurricaneFriction;

			if (Mathf.Abs(inputDir) > 0.01f)
			{
				// Accelerate toward target speed
				v.X = Mathf.MoveToward(v.X, targetX, accel * (float)delta);
			}
			else
			{
				// Slide slowly to a stop → slippery
				v.X = Mathf.MoveToward(v.X, 0f, friction * (float)delta);
			}

			// Apply hurricane's own wind forces (local)
			v.X += hz.CurrentWindX * (float)delta;
			v.Y += hz.CurrentVerticalPush * (float)delta;
		}
		else
		{
			// Normal region: standard direct control
			v.X = inputDir * MoveSpeed;
		}

		// ----------------------------
		// Global Wind Gusts (always active)
		// ----------------------------
		var gust = GustManager.Instance;
		if (gust != null)
		{
			float windAccel = gust.CurrentWind;
			v.X += windAccel * (float)delta;
		}

		// ----------------------------
		// Jump Input
		// ----------------------------
		bool jumpPressed = false;

		if (Input.IsActionJustPressed("ui_up") || Input.IsActionJustPressed("ui_accept"))
			jumpPressed = true;

		if (Input.IsKeyPressed(Key.W) || Input.IsKeyPressed(Key.Space))
			jumpPressed = true;

		if (jumpPressed && IsOnFloor())
			v.Y = JumpVelocity;

		// ----------------------------
		// Finalize movement
		// ----------------------------
		Velocity = v;
		MoveAndSlide();
	}
}
