using Godot;

public partial class Player : CharacterBody2D
{
	[Export] public float MoveSpeed = 260f;
	[Export] public float JumpVelocity = -400f;
	[Export] public float Gravity = 900f;

	public override void _PhysicsProcess(double delta)
	{
		Vector2 v = Velocity;

		// ----------------------------
		// Gravity
		// ----------------------------
		if (!IsOnFloor())
			v.Y += Gravity * (float)delta;

		// ----------------------------
		// Player Horizontal Input
		// ----------------------------
		float inputDir = 0f;

		if (Input.IsActionPressed("ui_left"))
			inputDir -= 1f;
		if (Input.IsActionPressed("ui_right"))
			inputDir += 1f;

		v.X = inputDir * MoveSpeed;

		// ----------------------------
		// Wind Gust Influence (Global)
		// ----------------------------

		// GustManager.Instance will be null until the scene loads it,
		// so we check before using it.
		var gust = GustManager.Instance;
		if (gust != null)
		{
			// gust.CurrentWind is acceleration (px/sec^2)
			float windAccel = gust.CurrentWind;

			// Apply as velocity change
			v.X += windAccel * (float)delta;
		}

		// ----------------------------
		// Jump Input
		// ----------------------------
		bool jumpPressed = false;

		// UI actions
		if (Input.IsActionJustPressed("ui_up") || Input.IsActionJustPressed("ui_accept"))
			jumpPressed = true;

		// Raw keyboard shortcuts
		if (Input.IsKeyPressed(Key.W) || Input.IsKeyPressed(Key.Space))
			jumpPressed = true;

		if (jumpPressed && IsOnFloor())
			v.Y = JumpVelocity;

		// ----------------------------
		// Finalize movement
		// ----------------------------
		Velocity = v;
		MoveAndSlide();
	}
}
