using Godot;

public partial class victoryMenu : CanvasLayer
{
	public override void _EnterTree()
	{
		ProcessMode = Node.ProcessModeEnum.Always;
	}

	public override void _Ready()
	{
		Visible = false;

		GD.Print("victoryMenu _Ready on: ", GetPath());

		// CanvasLayer/background/Panel/restartButton  "background/Panel/restartButton"
		// CanvasLayer/background/Panel/quitButton     "background/Panel/quitButton"
		var restartButton = GetNodeOrNull<Button>("background/Panel/restartButton");
		var quitButton    = GetNodeOrNull<Button>("background/Panel/quitButton");

		if (restartButton == null || quitButton == null)
		{
			GD.PrintErr("VictoryMenu: Could not find restart or quit buttons. Check node names and paths.");
			// Debug: list children under CanvasLayer
			foreach (Node child in GetChildren())
			{
				GD.Print("Child of CanvasLayer: ", child.Name, " (", child.GetType(), ")");
			}
			return;
		}

		restartButton.Pressed += OnRestartPressed;
		quitButton.Pressed += OnQuitPressed;

		GD.Print("Victory menu ready, buttons connected");
	}

	public void ShowMenu()
	{
		Visible = true;
		GetTree().Paused = true;
		GD.Print("Victory menu shown, game paused");
	}

	private void OnRestartPressed()
	{
		GD.Print("Restart pressed");
		GetTree().Paused = false;
		GetTree().ReloadCurrentScene();
	}

	private void OnQuitPressed()
	{
		GD.Print("Quit pressed");
		GetTree().Quit();
	}
}
