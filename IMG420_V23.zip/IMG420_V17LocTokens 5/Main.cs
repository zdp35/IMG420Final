using Godot;

public partial class Main : Node2D
{
	private victoryMenu _victoryMenu;

	public override void _Ready()
	{
		// Get a reference to the victory menu node
		_victoryMenu = GetNode<victoryMenu>("victoryMenu");
	}

	//  player wins
	private void OnPlayerWon()
	{
		_victoryMenu.ShowMenu();
	}
}
