using Godot;

public partial class AudioStreamPlayer2d2 : AudioStreamPlayer2D
{
	public override void _Ready()
	{
		Finished += OnFinished;

		Play();
	}

	private void OnFinished()
	{
		Play();
	}
}
