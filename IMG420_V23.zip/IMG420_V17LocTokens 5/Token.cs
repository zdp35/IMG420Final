using Godot;

public partial class Token : Area2D
{
    [Export]
    public int TokenIndex = 0;

    private TokenManager _tokenManager;

    public override void _Ready()
    {
        BodyEntered += OnBodyEntered;

        // Locate the TokenManager in the main scene
        // Assumes the root node is named "Main" and has a child called "TokenManager"
        _tokenManager = GetTree().Root.GetNode<TokenManager>("Main/TokenManager");
    }

    private void OnBodyEntered(Node2D body)
    {
        if (body is Player)
        {
            _tokenManager?.CollectToken(TokenIndex);
            QueueFree();
        }
    }
}
