using Godot;

public partial class TornadoZone : Area2D
{
	// How fast we launch the player upward (negative Y = up in Godot).
	[Export] public float LaunchVelocity = -1300f;

	// Optional horizontal push (e.g., to throw the player slightly right/left).
	[Export] public float HorizontalBoost = 0f;

	// Prevent double-firing immediately as the player stays in the area.
	[Export] public float CooldownSeconds = 0.0f;

	private double _cooldownTimer = 0.0;

	public override void _Process(double delta)
	{
		if (_cooldownTimer > 0.0)
			_cooldownTimer -= delta;
	}

	public override void _Ready()
	{
		// Godot 4 signal: body_entered(Node2D body)
		BodyEntered += OnBodyEntered;
	}

	private void OnBodyEntered(Node2D body)
	{
		// Only affect the Player
		if (_cooldownTimer > 0.0)
			return;

		if (body is Player player)
		{
			Vector2 v = player.Velocity;

			// Strong vertical launch
			v.Y = LaunchVelocity;

			// Optional sideways nudge
			if (HorizontalBoost != 0f)
				v.X += HorizontalBoost;

			player.Velocity = v;

			_cooldownTimer = CooldownSeconds;
		}
	}
}
