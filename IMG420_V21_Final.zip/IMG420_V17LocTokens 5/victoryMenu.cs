using Godot;

public partial class victoryMenu : CanvasLayer  // Changed from VictoryMenu to victoryMenu
{
	public override void _Ready()
	{
		// Hide initially
		Visible = false;
		
		// Connect buttons
		GetNode<Button>("Panel/restartButton").Pressed += OnRestartPressed;
		GetNode<Button>("Panel/quitButton").Pressed += OnQuitPressed;
	}
	
	public void Show()
	{
		Visible = true;
		GetTree().Paused = true;
	}
	
	private void OnRestartPressed()
	{
		GetTree().Paused = false;
		GetTree().ReloadCurrentScene();
	}
	
	private void OnQuitPressed()
	{
		GetTree().Quit();
	}
}
