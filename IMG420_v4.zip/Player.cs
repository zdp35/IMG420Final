using Godot;

public partial class Player : CharacterBody2D
{
    [Export] public float MoveSpeed = 240f;
    [Export] public float JumpVelocity = -380f;
    [Export] public float Gravity = 900f;

    public override void _PhysicsProcess(double delta)
    {
        Vector2 velocity = Velocity;

        if (!IsOnFloor())
            velocity.Y += Gravity * (float)delta;

        float inputDir = 0f;

        if (Input.IsActionPressed("ui_left"))
            inputDir -= 1f;
        if (Input.IsActionPressed("ui_right"))
            inputDir += 1f;

        if (Input.IsKeyPressed(Key.A))
            inputDir -= 1f;
        if (Input.IsKeyPressed(Key.D))
            inputDir += 1f;

        velocity.X = inputDir * MoveSpeed;

        bool jumpPressed = false;

        if (Input.IsActionJustPressed("ui_accept") || Input.IsActionJustPressed("ui_up"))
            jumpPressed = true;

        if (Input.IsKeyPressed(Key.W) || Input.IsKeyPressed(Key.Space))
            jumpPressed = true;

        if (jumpPressed && IsOnFloor())
            velocity.Y = JumpVelocity;

        Velocity = velocity;
        MoveAndSlide();
    }
}
