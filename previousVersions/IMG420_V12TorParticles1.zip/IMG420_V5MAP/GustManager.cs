using Godot;

public partial class GustManager : Node
{
	[Export] public float MinInterval = 2f;    // Min seconds between gusts
	[Export] public float MaxInterval = 4f;    // Max seconds between gusts
	[Export] public float MinStrength = 560f;  // Min gust strength (pixels/sec^2)
	[Export] public float MaxStrength = 9000f;  // Max gust strength (pixels/sec^2)
	[Export] public float GustDuration = 2f;   // How long a gust lasts (seconds)

	// Current wind acceleration applied to the player (positive = right, negative = left)
	public float CurrentWind { get; private set; } = 0f;

	public bool IsGusting => _gustTimeRemaining > 0.0;

	private double _timeToNextGust = 0.0;
	private double _gustTimeRemaining = 0.0;
	private float _activeStrength = 0f;

	private static GustManager _instance;
	public static GustManager Instance => _instance;

	private RandomNumberGenerator _rng = new RandomNumberGenerator();

	public override void _EnterTree()
	{
		_instance = this;
	}

	public override void _ExitTree()
	{
		if (_instance == this)
			_instance = null;
	}

	public override void _Ready()
	{
		_rng.Randomize();
		ScheduleNextGust();
	}

	public override void _Process(double delta)
	{
		if (_gustTimeRemaining > 0.0)
		{
			_gustTimeRemaining -= delta;

			if (_gustTimeRemaining <= 0.0)
			{
				// End gust
				_gustTimeRemaining = 0.0;
				CurrentWind = 0f;
				ScheduleNextGust();
			}
			else
			{
				// During gust: apply constant wind
				CurrentWind = _activeStrength;
			}
		}
		else
		{
			// Waiting for next gust
			_timeToNextGust -= delta;
			if (_timeToNextGust <= 0.0)
				StartNewGust();
		}
	}

	private void ScheduleNextGust()
	{
		// Random time until next gust
		_timeToNextGust = _rng.RandfRange(MinInterval, MaxInterval);
	}

	private void StartNewGust()
	{
		_gustTimeRemaining = GustDuration;

		// Direction: -1 (left) or +1 (right)
		float dir = _rng.Randf() < 0.5f ? -1f : 1f;

		// Strength between MinStrength and MaxStrength
		float strength = _rng.RandfRange(MinStrength, MaxStrength);

		_activeStrength = dir * strength;
		CurrentWind = _activeStrength;
	}
}
