using Godot;

public partial class TokenManager : Node
{
    [Export]
    public int TotalTokens = 7;

    private bool[] _collected;
    public int TokensCollected { get; private set; } = 0;

    public override void _Ready()
    {
        _collected = new bool[TotalTokens];
    }

    public void CollectToken(int tokenIndex)
    {
        if (tokenIndex < 0 || tokenIndex >= TotalTokens)
            return;

        if (_collected[tokenIndex])
            return;

        _collected[tokenIndex] = true;
        TokensCollected++;

        GD.Print($"Token collected: {tokenIndex} | {TokensCollected}/{TotalTokens}");

        if (TokensCollected >= TotalTokens)
        {
            GD.Print("All tokens collected! (Game can be completed now.)");
        }
    }
}
