using Godot;

public partial class HurricaneZone : Area2D
{
	[Export] public float MinStrength = 620f;       // min horizontal wind strength
	[Export] public float MaxStrength = 950f;       // max horizontal wind strength
	[Export] public float SwirlSpeed = 1.6f;        // how fast the wind direction oscillates
	[Export] public float VerticalPushStrength = 30f;  // subtle vertical wobble
	[Export] public float HurricaneAccel = 600f;    // how fast player accelerates toward input
	[Export] public float HurricaneFriction = 150f; // how fast player slows when no input

	// Values read by Player
	public float CurrentWindX { get; private set; } = 0f;
	public float CurrentVerticalPush { get; private set; } = 0f;

	private float _baseStrength;
	private double _time = 0.0;
	private RandomNumberGenerator _rng = new RandomNumberGenerator();

	public override void _Ready()
	{
		_rng.Randomize();
		_baseStrength = _rng.RandfRange(MinStrength, MaxStrength);

		BodyEntered += OnBodyEntered;
		BodyExited += OnBodyExited;
	}

	public override void _Process(double delta)
	{
		_time += delta;

		// Swirling horizontal wind: swings left/right over time
		float swirl = Mathf.Sin((float)_time * SwirlSpeed);   // -1 .. 1
		CurrentWindX = swirl * _baseStrength;

		// Subtle vertical wobble (can be tuned down or off)
		float wobble = Mathf.Cos((float)_time * SwirlSpeed);  // -1 .. 1
		CurrentVerticalPush = wobble * VerticalPushStrength;
	}

	private void OnBodyEntered(Node2D body)
	{
		if (body is Player player)
		{
			player.IsInHurricane = true;
			player.ActiveHurricaneZone = this;
		}
	}

	private void OnBodyExited(Node2D body)
	{
		if (body is Player player && player.ActiveHurricaneZone == this)
		{
			player.IsInHurricane = false;
			player.ActiveHurricaneZone = null;
		}
	}
}
