using Godot;

public partial class Player : CharacterBody2D
{
    [Export] public float MoveSpeed = 260f;
    [Export] public float JumpVelocity = -400f;
    [Export] public float Gravity = 900f;

    public override void _PhysicsProcess(double delta)
    {
        Vector2 v = Velocity;

        if (!IsOnFloor())
            v.Y += Gravity * (float)delta;

        float x = 0;

        if (Input.IsActionPressed("ui_left"))
            x -= 1;
        if (Input.IsActionPressed("ui_right"))
            x += 1;

        v.X = x * MoveSpeed;

        bool jumpPressed = false;

        if (Input.IsActionJustPressed("ui_up") || Input.IsActionJustPressed("ui_accept"))
            jumpPressed = true;

        if (Input.IsKeyPressed(Key.W) || Input.IsKeyPressed(Key.Space))
            jumpPressed = true;

        if (jumpPressed && IsOnFloor())
            v.Y = JumpVelocity;

        Velocity = v;
        MoveAndSlide();
    }
}
