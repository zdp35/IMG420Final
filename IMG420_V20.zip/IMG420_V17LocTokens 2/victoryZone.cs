using Godot;

public partial class victoryZone : Area2D  // Changed from VictoryZone to victoryZone
{
	public override void _Ready()
	{
		BodyEntered += OnBodyEntered;
	}
	
	private void OnBodyEntered(Node2D body)
	{
		GD.Print($"Body entered: {body.Name}");
		
		if (body.Name == "Player")
		{
			GD.Print("Player detected! Showing victory menu...");
			
			// Get the CanvasLayer (sibling node)
			var victoryMenu = GetNode<victoryMenu>("../CanvasLayer");
			
			if (victoryMenu != null)
			{
				victoryMenu.Show();
			}
			else
			{
				GD.Print("ERROR: VictoryMenu not found!");
			}
		}
	}
}
