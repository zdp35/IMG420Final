using Godot;

public partial class GustVisuals : Node2D
{
	private GpuParticles2D _gustParticles;

	public override void _Ready()
	{
		_gustParticles = GetNodeOrNull<GpuParticles2D>("GustParticles");
	}

	public override void _Process(double delta)
	{
		if (_gustParticles == null)
			return;

		var gust = GustManager.Instance;
		if (gust == null)
		{
			_gustParticles.Emitting = false;
			return;
		}

		float wind = gust.CurrentWind;

		if (Mathf.Abs(wind) < 10f)
		{
			_gustParticles.Emitting = false;
			return;
		}

		_gustParticles.Emitting = true;

		if (_gustParticles.ProcessMaterial is ParticleProcessMaterial mat)
		{
			float dirSign = Mathf.Sign(wind);
			mat.Direction = new Vector3(dirSign, 0f, 0f);

			float baseSpeed = 140f;
			float extra = Mathf.Clamp(Mathf.Abs(wind) * 0.2f, 0f, 200f);
			mat.InitialVelocityMin = baseSpeed;
			mat.InitialVelocityMax = baseSpeed + extra;
		}
	}
}
